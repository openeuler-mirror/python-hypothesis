============================
Examples of Hypothesis usage
============================

This is a directory for examples of using Hypothesis that show case its
features or demonstrate a useful way of testing something.

Right now it's a bit small and fairly algorithmically focused. Pull requests to
add more examples would be *greatly* appreciated, especially ones using e.g.
the Django integration or testing something "Businessy".
